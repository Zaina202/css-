"use strict";
(function(){
    window.addEventListener("load",init);
let object = {
    imageArray:[""]
    ,
  timeArray:["5h ago  •  Full Time","20h ago  •  Part Time","1d ago  •  Part Time",
        "2d ago  •  Full Time","2d ago  •  Part Time","4d ago  •  Part Time",
        "1w ago  •  Full Time","1w ago  •  Full Time","1w ago  •  Part Time",
      "2w ago  •  Freelance","1mo ago  •  Part Time","1mo ago  •  Part Time"]
,

jobArray:["Senior Software Engineer","Haskell and PureScript Dev","Midlevel Back End Engineer",
       "Senior Application Engineer","Remote DevOps Engineer","Desktop Support Manager",
       "iOS Engineer","Senior EJB Developer","Senior Frontend Developer",
       "App & Website Designer","Fullstack Developer","Technical Lead Engineer"]
,

companyArray:["Scoot","Blogr","Vector",
           "Office Lite","Pod","Creative",
           "Pomodoro","Maker","Coffeeroasters",
           "Mastercraft","Crowdfund","Typemaster"]

   ,        

areaArray:["United Kingdom","United states","Russia",
        "Japan","Thailand","Garmany",
        "United states","United Kingdom","Singapore",
        "United states","New Zealand","United Kingdom"]

}
function init(){
    let mydiv=qs('.divContainer')
   for(let i = 0;i<12;i++){
       let div1 = `<div id = "job">
       <img src = "${object.imageArray[i]}" alt = "">
       <p id = "p1">${object.timeArray[i]}</p>
       <p id = "p2">${object.jobArray[i]}</h3>
       <p id = "p1">${object.companyArray[i]}</p>
       <p id = "p3">${object.areaArray[i]}</p>
       </div>`;
       mydiv.innerHTML += div1;
   }
   let myBtn = '<div id = "btnDiv"><button id = "btnL" class= "button" >Load More</button></div>';
    mydiv.innerHTML+=myBtn;
}
function id(selector){
        return document.getElementById(selector);
}
function qs(selector){
    return document.querySelector(selector);
}
function qsa(selector){
    return document.querySelectorAll(selector);
}
})();